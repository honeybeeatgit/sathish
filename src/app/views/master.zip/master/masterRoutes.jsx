import { lazy } from "react";
import Loadable from "app/components/Loadable";

const Branch = Loadable(lazy(() => import("./branch/Appbranch")));
const Customer = Loadable(lazy(() => import("./customer/Appcustomer")));
const Consigne = Loadable(lazy(() => import("./consigne/Appconsigne")));

const masterRoutes = [
  { path: "/master/branch", element: <Branch /> },
  { path: "/master/customer", element: <Customer /> },
  { path: "/master/consigne", element: <Consigne /> }
];

export default masterRoutes;
