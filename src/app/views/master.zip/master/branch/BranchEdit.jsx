import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Button, TextField, Card, CardContent } from "@mui/material";
import Grid from "@mui/material/Grid2";
import Radio from "@mui/material/Radio";
import RadioGroup from "@mui/material/RadioGroup";
import FormControlLabel from "@mui/material/FormControlLabel";

const BranchEdit = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const [formData, setFormData] = useState({ name: "", address: "" });

    useEffect(() => {
        fetch(`/api/branches/${id}`)
            .then(response => response.json())
            .then(data => setFormData(data));
    }, [id]);

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        fetch(`/api/branches/${id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(formData),
        }).then(() => navigate("/branch"));
    };

    return (
<div>

                <h2>Edit Branch</h2>
                <form onSubmit={handleSubmit}>
                    <Grid container spacing={2} sx={{ mb: 2 }} >
                        <Grid item xs={12}>
                            <TextField
                                fullWidth
                                type="text"
                                name="username"
                                value={formData.username}
                                onChange={handleChange}
                                label="Username"
                            />
                        </Grid>
                        <Grid item xs={12}>
                            <TextField
                                fullWidth
                                type="text"
                                name="firstName"
                                value={formData.firstName}
                                onChange={handleChange}
                                label="First Name"
                            />
                        </Grid>
                        <Grid item xs={12}>
                            <TextField
                                fullWidth
                                type="email"
                                name="email"
                                value={formData.email}
                                onChange={handleChange}
                                label="Email"
                            />
                        </Grid>
                        <Grid item xs={12}>
                            <TextField
                                fullWidth
                                type="number"
                                name="creditCard"
                                value={formData.creditCard}
                                onChange={handleChange}
                                label="Credit Card"
                            />
                        </Grid>
                    </Grid>


                    <Grid container spacing={2} sx={{ mb: 2 }}>
                        <Grid item md={3} xs={12}>
                        <TextField
                            fullWidth
                            type="text"
                            name="mobile"
                            value={formData.mobile}
                            onChange={handleChange}
                            label="Mobile Number"
                        />
                        </Grid>
                        <Grid item md={3} xs={12}>
                        <TextField
                            fullWidth
                            type="password"
                            name="password"
                            value={formData.password}
                            onChange={handleChange}
                            label="Password"
                        />
                        </Grid>
                        <Grid item md={3} xs={12}>
                        <TextField
                            fullWidth
                            type="password"
                            name="confirmPassword"
                            value={formData.confirmPassword}
                            onChange={handleChange}
                            label="Confirm Password"
                        />
                        </Grid>
                    </Grid>

                    <Button variant="contained" color="primary" type="submit">Update Branch</Button>
                </form>
        </div>
    );
};

export default BranchEdit;
