import { useState } from "react";
import Button from "@mui/material/Button";
// import Checkbox from "@mui/material/Checkbox";
import FormControlLabel from "@mui/material/FormControlLabel";
import Icon from "@mui/material/Icon";
import Radio from "@mui/material/Radio";
import RadioGroup from "@mui/material/RadioGroup";
import TextField from "@mui/material/TextField";
import Grid from "@mui/material/Grid2";
// import Stack from "@mui/material/Stack";
import { Span } from "app/components/Typography";
// import { useParams, useNavigate } from "react-router-dom"; 

const BranchAdd = () => {
  const [state, setState] = useState({
    email: "",
    mobile: "",
    gender: "",
    username: "",
    password: "",
    firstName: "",
    creditCard: "",
    confirmPassword: ""
  });

  const handleSubmit = (event) => {
    console.log("submitted");
    console.log(event);
  };

  const handleChange = (event) => {
    event.persist();
    setState({ ...state, [event.target.name]: event.target.value });
  };

  const { username, firstName, creditCard, mobile, password, confirmPassword, gender, email } =
    state;

  return (
    <div>
      <form onSubmit={handleSubmit}>
          <Grid container spacing={2} sx={{ mb: 2 }}>
              <Grid item md={3} xs={12}>
                <TextField
                  fullWidth
                  type="text"
                  name="username"
                  value={username}
                  onChange={handleChange}
                  label="Username"
                />
              </Grid>
              <Grid item md={4} xs={12}>
                <TextField
                  fullWidth
                  type="text"
                  name="firstName"
                  value={firstName}
                  onChange={handleChange}
                  label="First Name"
                />
              </Grid>
              <Grid item md={4} xs={12}>
                <TextField
                  fullWidth
                  type="email"
                  name="email"
                  value={email}
                  onChange={handleChange}
                  label="Email"
                />
              </Grid>
              <Grid item md={4} xs={12}>
                <TextField
                  fullWidth
                  type="number"
                  name="creditCard"
                  value={creditCard}
                  onChange={handleChange}
                  label="Credit Card"
                />
              </Grid>
          </Grid>


          <Grid container spacing={2} sx={{ mb: 2 }}>
            <Grid item md={3} xs={12}>
              <TextField
                fullWidth
                type="text"
                name="mobile"
                value={mobile}
                onChange={handleChange}
                label="Mobile Number"
              />
            </Grid>
            <Grid item md={3} xs={12}>
              <TextField
                fullWidth
                type="password"
                name="password"
                value={password}
                onChange={handleChange}
                label="Password"
              />
            </Grid>
            <Grid item md={3} xs={12}>
              <TextField
                fullWidth
                type="password"
                name="confirmPassword"
                value={confirmPassword}
                onChange={handleChange}
                label="Confirm Password"
              />
            </Grid>
            <Grid item md={3} xs={12}>
              <RadioGroup row name="gender" value={gender} onChange={handleChange}>
                <FormControlLabel value="Male" control={<Radio />} label="Male" />
                <FormControlLabel value="Female" control={<Radio />} label="Female" />
                <FormControlLabel value="Others" control={<Radio />} label="Others" />
              </RadioGroup>
            </Grid>
          </Grid>
          
        {/* <Grid container spacing={2} sx={{ mb: 2 }}>
          <Grid item md={12} xs={12}>
            <FormControlLabel
              control={<Checkbox />}
              label="I have read and agree to the terms of service."
            />
          </Grid>
        </Grid> */}

        <Grid container spacing={2} sx={{ mb: 2 }}>
          <Button color="primary" variant="contained" type="submit">
            <Icon>send</Icon>
            <Span sx={{ pl: 1, textTransform: "capitalize" }}>Submit</Span>
          </Button>
          <Button color="secondary" variant="contained" type="submit">
            <Span sx={{ pl: 1, textTransform: "capitalize" }} onClick={() => navigate("/")}>Back</Span>
          </Button>
        </Grid>
      </form>
    </div>
  );
};

export default BranchAdd;

console.log("BranchAdd component loaded")